﻿using Autoskola.Core.Models;
using Autoskola.Core.ViewModels;
using Autoskola.Service.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Autoskola.API.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class CityController : ControllerBase
    {
        private readonly ICityService service;

        public CityController(ICityService service)
        {
            this.service = service;
        }

        [HttpGet]
        public IActionResult GetAll([FromQuery] int start = 1, int range = 100)
        {
                return Ok(service.GetAll(start, range));
        }

        [HttpGet("{id}")]
        public IActionResult GetById( int id)
        {
            return Ok(service.GetById(id));
        }

        [HttpPost]
        public IActionResult Add([FromBody] CityAddVM city)
        {
            return Ok(service.Add(city));
        }
        [HttpDelete("{id}")]
        public IActionResult Remove(int id)
        {
            return Ok(service.Remove(id));
        }
        [HttpPut]
        public IActionResult Update([FromBody] City city)
        {
            service.Update(city);
            return Ok(city);
        }
    }
}
