﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autoskola.Core.ViewModels
{
    public class CityAddVM
    {
        public string Name { get; set; }
        public int PostalCode { get; set; }
    }
}
