﻿using AutoMapper;
using Autoskola.Repository.Data;
using Autoskola.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;
using PagedList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autoskola.Repository.Repositories
{
    public class GenericRepository<TEntity, TKey> : IRepository<TEntity, TKey> where TEntity : class
    {
        private readonly ApplicationContext dbContext;
        private readonly DbSet<TEntity> dbSet;
        public GenericRepository(ApplicationContext dbContext)
        {
            this.dbContext = dbContext;
            this.dbSet = dbContext.Set<TEntity>();
        }

        public TEntity Add(TEntity entity)
        {
            dbSet.Add(entity);
            dbContext.SaveChanges();
            return entity;
        }

        public TEntity Update(TEntity entity)
        {
            dbSet.Update(entity);
            dbContext.SaveChanges();
            return entity;
        }

        public TEntity Remove(TEntity entity)
        {
            dbSet.Remove(entity);
            dbContext.SaveChanges();
            return entity;
        }

        public IEnumerable<TEntity> GetAll(int start, int range)
        {
            return dbSet.ToPagedList(start, range);
        }

        public TEntity GetById(TKey key)
        {
            return dbSet.Find(key);
        }
    }
}
