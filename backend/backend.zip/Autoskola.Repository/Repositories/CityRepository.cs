﻿using Autoskola.Core.Models;
using Autoskola.Repository.Data;
using Autoskola.Repository.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Autoskola.Repository.Repositories
{
    public class CityRepository : GenericRepository<City, int>, ICityRepository
    {
        public CityRepository(ApplicationContext dbContext) : base(dbContext)
        {
        }
    }
}
